import { useNavigate } from 'react-router-dom';
import { useEffect } from 'react';
import { motion } from 'motion/react';
import { supabase } from '../../lib/supabase';

const GOLD = '#E8B86D';
const TEAL = '#3ECFB2';

export default function Splash() {
  const navigate = useNavigate();

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session) {
        const role = (session.user.user_metadata as any)?.role || 'guest';
        if (role === 'host') {
          navigate('/host');
        } else {
          navigate('/home');
        }
      }
    });
  }, [navigate]);

  return (
    <div className="flex items-center justify-center min-h-screen p-6" style={{ background: '#06060c' }}>
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.6 }}
        className="w-full max-w-[390px] h-[844px] rounded-[44px] overflow-hidden relative"
        style={{
          background: '#0D0F14',
          border: '1px solid rgba(255,255,255,0.06)',
          boxShadow: '0 60px 120px rgba(0,0,0,0.9)',
        }}
      >
        {/* Background */}
        <div className="absolute inset-0" style={{
          background: `
            radial-gradient(ellipse 70% 50% at 30% 40%, rgba(232,184,109,0.1) 0%, transparent 70%),
            radial-gradient(ellipse 70% 50% at 70% 60%, rgba(62,207,178,0.08) 0%, transparent 70%),
            linear-gradient(180deg, #0D0F14 0%, #0A0B10 100%)
          `
        }} />
        <div className="absolute inset-0" style={{
          backgroundImage: `
            linear-gradient(rgba(232,184,109,0.03) 1px, transparent 1px),
            linear-gradient(90deg, rgba(232,184,109,0.03) 1px, transparent 1px)
          `,
          backgroundSize: '30px 30px'
        }} />

        <div className="relative z-10 flex flex-col items-center justify-between h-full px-8 pt-16 pb-12 text-center">

          {/* Logo section */}
          <div className="flex flex-col items-center">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2, type: 'spring', stiffness: 200 }}
              className="w-[80px] h-[80px] rounded-[22px] flex items-center justify-center mb-5"
              style={{
                background: `linear-gradient(135deg, ${GOLD}, #D4A045)`,
                boxShadow: `0 20px 40px rgba(232,184,109,0.35)`,
                fontFamily: 'var(--font-playfair)',
                fontSize: '36px',
                fontWeight: 900,
                color: '#0D0F14',
              }}
            >
              L
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              style={{
                fontFamily: 'var(--font-playfair)',
                fontSize: '48px',
                fontWeight: 900,
                letterSpacing: '-1px',
                background: `linear-gradient(135deg, #F5D08A, ${GOLD})`,
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                marginBottom: '6px',
              }}
            >
              LALA
            </motion.h1>

            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.35 }}
              className="text-sm mb-4"
              style={{ color: 'rgba(255,255,255,0.4)', letterSpacing: '2px' }}
            >
              KENYA · PATA LALA SASA
            </motion.p>

            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.4 }}
              className="text-[14px] max-w-[260px]"
              style={{ color: 'rgba(255,255,255,0.35)', lineHeight: '1.8' }}
            >
              Instant short-stays, anywhere.<br />
              Verified hosts. Fast M-Pesa payments.
            </motion.p>
          </div>

          {/* FULLY SEPARATED ENTRY POINTS */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.55 }}
            className="w-full flex flex-col gap-4"
          >
            <div className="text-[10px] text-center mb-1" style={{ color: 'rgba(255,255,255,0.2)', letterSpacing: 2 }}>
              SELECT YOUR ROLE TO CONTINUE
            </div>

            {/* GUEST — takes to guest login/signup */}
            <motion.button
              whileTap={{ scale: 0.97 }}
              onClick={() => navigate('/login/guest')}
              className="w-full rounded-[20px] p-5 text-left cursor-pointer border-none"
              style={{
                background: 'rgba(232,184,109,0.08)',
                border: `1.5px solid rgba(232,184,109,0.28)`,
              }}
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-[14px] flex items-center justify-center text-[26px]"
                  style={{ background: 'rgba(232,184,109,0.14)' }}>
                  🏨
                </div>
                <div className="flex-1 text-left">
                  <div className="text-[17px] font-bold" style={{ color: 'white', fontFamily: 'var(--font-playfair)' }}>
                    I'm a Guest
                  </div>
                  <div className="text-[12px] mt-0.5" style={{ color: 'rgba(255,255,255,0.4)' }}>
                    Find & book short stays
                  </div>
                </div>
                <span style={{ color: GOLD, fontSize: 20 }}>→</span>
              </div>
            </motion.button>

            {/* HOST — takes to host login/signup */}
            <motion.button
              whileTap={{ scale: 0.97 }}
              onClick={() => navigate('/login/host')}
              className="w-full rounded-[20px] p-5 text-left cursor-pointer border-none"
              style={{
                background: 'rgba(62,207,178,0.07)',
                border: `1.5px solid rgba(62,207,178,0.22)`,
              }}
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-[14px] flex items-center justify-center text-[26px]"
                  style={{ background: 'rgba(62,207,178,0.1)' }}>
                  🏠
                </div>
                <div className="flex-1 text-left">
                  <div className="text-[17px] font-bold" style={{ color: 'white', fontFamily: 'var(--font-playfair)' }}>
                    List My Stay
                  </div>
                  <div className="text-[12px] mt-0.5" style={{ color: 'rgba(255,255,255,0.4)' }}>
                    Host & earn with your property
                  </div>
                </div>
                <span style={{ color: TEAL, fontSize: 20 }}>→</span>
              </div>
            </motion.button>

            <p className="text-[11px] mt-1 text-center" style={{ color: 'rgba(255,255,255,0.18)', lineHeight: '1.6' }}>
              By continuing you agree to our Terms & Privacy Policy
            </p>
          </motion.div>
        </div>
      </motion.div>
    </div>
  );
}
