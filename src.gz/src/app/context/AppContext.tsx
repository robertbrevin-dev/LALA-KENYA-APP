import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';



import { Property, User, Booking, Conversation, Message, CallStatus } from '../types';



import { supabase } from '../../lib/supabase';



import { useLanguage } from './LanguageContext.tsx';







interface AppContextType {



  properties: Property[];



  currentUser: User | null;



  favorites: string[];



  bookings: Booking[];



  conversations: Conversation[];



  callStatus: CallStatus;
  callConnected: boolean;
  notifications: any[];
  unreadCount: number;
  markNotificationRead: (id: string) => void;
  markAllNotificationsRead: () => void;



  loading: boolean;



  refreshUser: () => Promise<void>;



  toggleFavorite: (propertyId: string) => void;



  addBooking: (booking: Booking) => void;



  sendMessage: (conversationId: string, text: string) => void;



  sendSimulatedMessage: (conversationId: string, senderId: string, senderName: string, text: string) => void;



  createConversation: (



    booking: Booking,



    participantRole: 'guest' | 'host',



    participantName: string,



    participantId: string,



    participantPhone?: string



  ) => Promise<string>;



  startCall: (conversationId: string, participantName: string, participantPhone?: string, receiverId?: string, callType?: string) => void;
  acceptCall: (call: any) => void;
  rejectCall: (call: any) => void;
  incomingCall: any;



  endCall: () => void;



  markMessagesAsRead: (conversationId: string) => void;



  updateUserAvatar: (url: string) => Promise<void>;



  removeUserAvatar: () => Promise<void>;



  logout: () => Promise<void>;



}







const AppContext = createContext<AppContextType | undefined>(undefined);







export function AppProvider({ children }: { children: ReactNode }) {



  const { t } = useLanguage();



  const [properties, setProperties] = useState<Property[]>([]);



  const [currentUser, setCurrentUser] = useState<User | null>(null);



  const [favorites, setFavorites] = useState<string[]>([]);



  const [bookings, setBookings] = useState<Booking[]>([]);



  const [conversations, setConversations] = useState<Conversation[]>([]);



  const [callStatus, setCallStatus] = useState<CallStatus>({ active: false });
  const [callConnected, setCallConnected] = useState(false);
  const peerRef = React.useRef<RTCPeerConnection | null>(null);
  const localStreamRef = React.useRef<MediaStream | null>(null);
  const createPeer = () => new RTCPeerConnection({ iceServers: [{ urls: 'stun:stun.l.google.com:19302' }, { urls: 'stun:stun1.l.google.com:19302' }] });
  const cleanupWebRTC = () => {
    if (peerRef.current) { peerRef.current.close(); peerRef.current = null; }
    if (localStreamRef.current) { localStreamRef.current.getTracks().forEach(t => t.stop()); localStreamRef.current = null; }
  };
  const [incomingCall, setIncomingCall] = useState<any>(null);

  useEffect(() => {
    if (!currentUser?.id) return;
    const sub = supabase.channel('incoming-calls-' + currentUser.id)
      .on('postgres_changes', {
        event: 'INSERT', schema: 'public', table: 'calls',
        filter: 'receiver_id=eq.' + currentUser.id
      }, async (payload) => {
        const call = payload.new;
        console.log('INCOMING CALL PAYLOAD:', call, 'status:', call.call_status);
        const { data: caller } = await supabase.from('profiles').select('full_name').eq('id', call.caller_id).maybeSingle();
        console.log('CALLER NAME:', caller?.full_name);
        setIncomingCall({ ...call, caller_name: caller?.full_name || 'Unknown' });
        console.log('incomingCall SET');
      })
      .on('postgres_changes', {
        event: 'UPDATE', schema: 'public', table: 'calls',
        filter: 'receiver_id=eq.' + currentUser.id
      }, (payload) => {
        if (payload.new.call_status === 'ended') {
          setCallStatus({ active: false });
          setIncomingCall(null);
        }
      })
      .on('postgres_changes', {
        event: 'UPDATE', schema: 'public', table: 'calls',
        filter: 'receiver_id=eq.' + currentUser.id
      }, (payload) => {
        if (payload.new.call_status === 'ended') {
          setCallStatus({ active: false });
          setIncomingCall(null);
        }
      })
      .on('postgres_changes', {
        event: 'INSERT', schema: 'public', table: 'call_ice_candidates',
        filter: 'user_id=neq.' + currentUser.id
      }, async (payload) => {
        if (peerRef.current && payload.new.candidate) {
          try { await peerRef.current.addIceCandidate(new RTCIceCandidate(payload.new.candidate)); } catch(e) {}
        }
      })
      .on('postgres_changes', {
        event: 'UPDATE', schema: 'public', table: 'calls',
        filter: 'caller_id=eq.' + currentUser.id
      }, async (payload) => {
        if (payload.new.call_status === 'rejected' || payload.new.call_status === 'ended') {
          setCallStatus({ active: false });
          setCallConnected(false);
        }
        if (payload.new.call_status === 'accepted') {
          setCallStatus(prev => ({ ...prev, active: true }));
          setCallConnected(true);
          // Apply SDP answer on caller side
          if (peerRef.current && payload.new.sdp_answer) {
            try {
              await peerRef.current.setRemoteDescription(new RTCSessionDescription(JSON.parse(payload.new.sdp_answer)));
              const { data: cands } = await supabase.from('call_ice_candidates').select('*').eq('call_id', payload.new.id).neq('user_id', currentUser.id);
              for (const cand of cands || []) { try { await peerRef.current.addIceCandidate(new RTCIceCandidate(cand.candidate)); } catch(e) {} }
            } catch(err) { console.error('Apply answer error:', err); }
          }
        }
      })
      .subscribe();
    return () => { supabase.removeChannel(sub); };
  }, [currentUser?.id]);

  useEffect(() => {
    if (!currentUser?.id) return;
    supabase.from('notifications').select('*').eq('user_id', currentUser.id).order('created_at', { ascending: false }).limit(50)
      .then(({ data }) => { if (data) setNotifications(data); });
    const sub = supabase.channel('notifications-' + currentUser.id)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'notifications', filter: 'user_id=eq.' + currentUser.id },
        (payload) => { setNotifications(prev => [payload.new, ...prev]); })
      .subscribe();
    return () => { supabase.removeChannel(sub); };
  }, [currentUser?.id]); // Load notifications

  useEffect(() => {
    if (!currentUser?.id) return;
    const autoExpire = async () => {
      await supabase.from('bookings').update({ booking_status: 'expired' })
        .eq('booking_status', 'inquiry')
        .lt('created_at', new Date(Date.now() - 5 * 60 * 1000).toISOString());
      await supabase.from('bookings').update({ booking_status: 'expired' })
        .eq('booking_status', 'accepted')
        .lt('updated_at', new Date(Date.now() - 30 * 60 * 1000).toISOString());
      await supabase.from('bookings').update({ booking_status: 'completed', is_available: true })
        .eq('booking_status', 'checked_in')
        .lt('check_out', new Date().toISOString().slice(0, 10));
    };
    autoExpire();
    // Check-in reminder: notify guests day before
    const sendCheckinReminders = async () => {
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      const tomorrowStr = tomorrow.toISOString().slice(0, 10);
      const { data: upcoming } = await supabase.from('bookings')
        .select('*').eq('booking_status', 'paid').eq('check_in', tomorrowStr);
      for (const b of upcoming || []) {
        const { data: existing } = await supabase.from('notifications')
          .select('id').eq('user_id', b.guest_id).eq('type', 'checkin_reminder')
          .eq('data->>booking_id', b.id).limit(1);
        if (!existing?.length) {
          const { sendNotification } = await import('../utils/notify');
          await sendNotification({
            userId: b.guest_id, type: 'checkin_reminder',
            bookingId: b.id, propertyTitle: b.property_title,
            checkIn: b.check_in,
          });
        }
      }
    };
    sendCheckinReminders();
    const t = setInterval(() => { autoExpire(); sendCheckinReminders(); }, 60000);
    return () => clearInterval(t); // auto-expire
  }, [currentUser?.id]);



  const [loading, setLoading] = useState(true); // fetch notifications
  const [notifications, setNotifications] = useState<any[]>([]);
  const unreadCount = notifications.filter(n => !n.is_read).length;

  const markNotificationRead = async (id: string) => {
    await supabase.from('notifications').update({ is_read: true }).eq('id', id);
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, is_read: true } : n));
  };

  const markAllNotificationsRead = async () => {
    if (!currentUser?.id) return;
    await supabase.from('notifications').update({ is_read: true }).eq('user_id', currentUser.id).eq('is_read', false);
    setNotifications(prev => prev.map(n => ({ ...n, is_read: true })));
  };







  const clearState = () => {



    setCurrentUser(null);



    setFavorites([]);



    setBookings([]);



    setConversations([]);



    setCallStatus({ active: false });



  };







  const logout = async () => {



    await supabase.auth.signOut();



    clearState();



    // Always send users to the auth chooser after logout



    window.location.href = '/signup';



  };







  useEffect(() => {



    let mounted = true;







    async function getUser() {



      const { data: { session } } = await supabase.auth.getSession();



      if (!mounted) return;



      if (session?.user) {



        // Fetch user profile to get role from profiles table



        const { data: profile } = await supabase.from('profiles').select('role').eq('id', session.user.id).single();



        



        console.log('🔍 Auth Debug:', {



          userId: session.user.id,



          profile: profile,



          profileRole: profile?.role,



          finalRole: profile?.role || 'guest'



        });



        



        setCurrentUser({



          id: session.user.id,



          name: session.user.user_metadata?.full_name || 'User',



          email: session.user.email || '',



          phone: session.user.user_metadata?.phone || '',



          avatar: session.user.user_metadata?.avatar_url || undefined,



          role: (profile?.role || 'guest') as 'guest' | 'host',



        });



      } else {



        setCurrentUser(null);



      }



      setLoading(false);



    }







    getUser();







    const { data: authListener } = supabase.auth.onAuthStateChange((_event: string, session: any) => {



      if (!mounted) return;



      console.log('AUTH EVENT:', _event, 'session:', !!session, 'user:', !!session?.user);



      if (_event === 'INITIAL_SESSION') return;



      if (_event === 'SIGNED_OUT') {



        clearState();



        setLoading(false);



        window.location.href = '/signup';



        return;



      }



      if (session?.user) {



        const fetchProfile = async () => {



          const { data: profile } = await supabase



            .from('profiles')



            .select('role, full_name, avatar_url')



            .eq('id', session.user.id)



            .single();



          if (!mounted) return;



          setCurrentUser({



            id: session.user.id,



            name: profile?.full_name || session.user.user_metadata?.full_name || session.user.user_metadata?.name || 'User',



            email: session.user.email || '',



            phone: session.user.user_metadata?.phone || '',



            avatar: profile?.avatar_url || session.user.user_metadata?.avatar_url || undefined,



            // ALWAYS read role from profiles table — never from auth metadata on login



        role: (profile?.role || 'guest') as 'guest' | 'host',



          });



          // Set loading=false ONLY after role is known



          setLoading(false);



        };



        fetchProfile();



      } else {



        setCurrentUser(null);



        setLoading(false);



      }



    });







    return () => {



      mounted = false;



      authListener.subscription.unsubscribe();



    };



  }, []);







  const refreshUser = async (forceRole?: 'guest' | 'host') => {



    if (forceRole) sessionStorage.setItem('lala-force-role', forceRole);



    const { data: { session } } = await supabase.auth.getSession();



    if (session?.user) {



      const { data: profile } = await supabase.from('profiles').select('role, full_name, avatar_url').eq('id', session.user.id).single();



      setCurrentUser({



        id: session.user.id,



        name: profile?.full_name || session.user.user_metadata?.full_name || 'User',



        email: session.user.email || '',



        phone: session.user.user_metadata?.phone || '',



        avatar: profile?.avatar_url || session.user.user_metadata?.avatar_url || undefined,



        role: (forceRole || sessionStorage.getItem('lala-force-role') || profile?.role || 'guest') as 'guest' | 'host',



      });



    }



  };







  const updateUserAvatar = async (url: string) => {



    await supabase.auth.updateUser({ data: { avatar_url: url } });



    setCurrentUser(prev => (prev ? { ...prev, avatar: url } : prev));



  };







  const removeUserAvatar = async () => {



    const existing = currentUser?.avatar;



    try {



      if (existing && existing.includes('/storage/v1/object/public/avatars/')) {



        const parts = existing.split('/storage/v1/object/public/avatars/');



        const path = parts[1]?.split('?')[0];



        if (path) await supabase.storage.from('avatars').remove([path]);



      }



    } catch {}



    await supabase.auth.updateUser({ data: { avatar_url: null as any } });



    setCurrentUser(prev => (prev ? { ...prev, avatar: undefined } : prev));



  };







  useEffect(() => {



    async function fetchProperties() {



      setLoading(true);



      const { data, error } = await supabase



        .from('properties')



        .select(`



          id, title, location, area, price_per_night, rating, total_reviews,



          primary_image_url, property_type, badge, bedrooms, beds, max_guests,



          description, amenities, host_id, is_featured, instant_book,



          house_rules, cancellation_policy, cleaning_fee, response_time,



          response_rate, listing_status, latitude, longitude, image_urls,
          profiles!host_id (full_name, avatar_url, created_at)



        `)



        .eq('listing_status', 'approved')



        .order('created_at', { ascending: false });







      if (error) {



        setProperties([]); // No mock data — real listings only



        setLoading(false);



        return;



      }







      if (data) {



        const mapped: Property[] = data.map((p: any) => ({



          id: p.id,



          title: p.title,



          location: p.area || (p.location?.startsWith?.("POINT") ? "" : p.location) || "",



          latitude: p.latitude ?? null,



          images: p.image_urls ?? [],



          longitude: p.longitude ?? null,



          price: p.price_per_night,



          rating: p.rating ?? 0,



          reviews: p.total_reviews ?? 0,



          image: p.primary_image_url || '🏢',



          category: p.property_type || 'Apartment',



          badge: p.badge ?? undefined,



          isFavorite: false,



          bedrooms: p.bedrooms ?? 1,



          beds: p.beds ?? 1,



          guests: p.max_guests ?? 2,



          description: p.description ?? '',



          amenities: p.amenities ?? [],



          hostId: p.host_id,



          hostName: p.profiles?.full_name || 'Host',



          hostJoined: p.profiles?.created_at ?? undefined,



          verified: p.is_featured ?? false,



          instantBook: p.instant_book ?? false,



          houseRules: p.house_rules ?? [],



          cancellationPolicy: p.cancellation_policy ?? undefined,



          cleaningFee: p.cleaning_fee ?? 0,



          responseTime: p.response_time ?? undefined,



          responseRate: p.response_rate ?? undefined,



        }));



        setProperties(mapped);



      }



      setLoading(false);



    }



    fetchProperties();



  }, []);







  // Load real conversations + messages from Supabase



  useEffect(() => {



    if (!currentUser) {



      setConversations([]);



      return;



    }



    async function fetchConversations() {



      const userCol = currentUser!.role === 'host' ? 'host_id' : 'guest_id';



      let { data: convData, error: convError } = await supabase



        .from('conversations')



        .select('*')



        .eq(userCol, currentUser!.id)



        .order('last_message_time', { ascending: false });



      if (convError) { console.error('Conversations fetch error:', convError.message); return; }
      const bookingIds = (convData || []).map((c: any) => c.booking_id).filter(Boolean);
      const { data: bookingStatuses } = bookingIds.length > 0
        ? await supabase.from('bookings').select('id, booking_status').in('id', bookingIds)
        : { data: [] };
      const statusMap: Record<string, string> = {};
      (bookingStatuses || []).forEach((b: any) => { statusMap[b.id] = b.booking_status; });
      const activeStatuses = ['accepted', 'payment_pending', 'paid', 'checked_in'];
      convData = (convData || []).filter((conv: any) => {
        const status = statusMap[conv.booking_id];
        return !status || activeStatuses.includes(status);
      });



      if (!convData || convData.length === 0) return;



      const convIds = convData.map((c: any) => c.id);



      const { data: msgData } = await supabase



        .from('messages')



        .select('*')



        .in('conversation_id', convIds)



        .order('created_at', { ascending: true });



      const msgsByConv: Record<string, Message[]> = {};



      (msgData ?? []).forEach((m: any) => {



        if (!msgsByConv[m.conversation_id]) msgsByConv[m.conversation_id] = [];



        msgsByConv[m.conversation_id].push({



          id: m.id, conversationId: m.conversation_id,



          senderId: m.sender_id, senderName: m.sender_name,



          text: m.text, timestamp: m.created_at, read: m.read,



        });



      });



      const mapped: Conversation[] = convData.map((c: any) => {



        const msgs = msgsByConv[c.id] ?? [];



        const unread = msgs.filter((m: Message) => !m.read && m.senderId !== currentUser!.id).length;



        return {



          id: c.id, bookingId: c.booking_id,



          propertyTitle: c.property_title, propertyImage: c.property_image || '',



          participantId: c.participant_id || '', participantName: currentUser?.role === 'host' ? (c.guest_name || c.participant_name || 'Guest') : (c.host_name || c.participant_name || 'Host'),



          participantPhone: c.participant_phone, participantRole: c.participant_role || 'host',



          lastMessage: c.last_message || 'Start a conversation',



          lastMessageTime: c.last_message_time, unreadCount: unread, messages: msgs,



        };



      });



      setConversations(mapped);



    }



    fetchConversations();



  }, [currentUser]);







  // Load user favorites when logged in



  useEffect(() => {



    if (!currentUser) {



      setFavorites([]);



      return;



    }







    async function fetchFavorites() {



      const { data, error } = await supabase



        .from('favorites')



        .select('property_id')



        .eq('user_id', currentUser?.id);







      if (error) {



        console.error('Favorites fetch error:', error.message);



        return;



      }







      if (data) {



        const favoriteIds = data.map(f => f.property_id);



        setFavorites(favoriteIds);



        



        // Update properties to reflect favorite status



        setProperties(prev => prev.map(p => ({



          ...p,



          isFavorite: favoriteIds.includes(p.id)



        })));



      }



    }







    fetchFavorites();



  }, [currentUser]);







  // Load user bookings when logged in



  useEffect(() => {



    if (!currentUser) {



      setBookings([]);



      return;



    }







    async function fetchBookings() {



      const { data, error } = await supabase



        .from('bookings')



        .select('*')



        .eq('guest_id', currentUser?.id)



        .order('check_in', { ascending: false });







      if (error) {



        console.error('Bookings fetch error:', error.message);



        return;



      }







      if (data) {



        const mappedBookings: Booking[] = data.map(b => ({



          id: b.id,



          propertyId: b.property_id,



          propertyTitle: b.property_title,



          propertyLocation: b.property_location,



          guestId: b.guest_id,



          guestName: b.guest_name,



          guestPhone: b.guest_phone,



          checkIn: b.check_in,



          checkOut: b.check_out,



          nights: b.nights,



          totalAmount: b.total_amount,



          status: b.booking_status,



          createdAt: b.created_at,



        }));



        setBookings(mappedBookings);



      }



    }







    fetchBookings();



  }, [currentUser]);







  const toggleFavorite = async (propertyId: string) => {



    if (!currentUser) return;



    const isFav = favorites.includes(propertyId);



    if (isFav) {



      setFavorites(prev => prev.filter(id => id !== propertyId));



      await supabase.from('favorites').delete().eq('property_id', propertyId).eq('user_id', currentUser.id);



    } else {



      setFavorites(prev => [...prev, propertyId]);



      await supabase.from('favorites').insert({ user_id: currentUser.id, property_id: propertyId });



    }



    setProperties(prev => prev.map(p => p.id === propertyId ? { ...p, isFavorite: !isFav } : p));



  };







  const addBooking = async (booking: Booking) => {



    if (!currentUser) return;



    const { error } = await supabase.from('bookings').insert({



      id: booking.id,



      property_id: booking.propertyId,



      guest_id: currentUser.id,



      property_title: booking.propertyTitle,



      property_location: booking.propertyLocation,



      guest_name: booking.guestName,



      guest_phone: booking.guestPhone,



      check_in: booking.checkIn,



      check_out: booking.checkOut,



      nights: booking.nights,



      base_amount: booking.totalAmount,



      total_amount: booking.totalAmount,



      currency: 'KES',



      booking_status: booking.status,



    });



    if (!error) setBookings(prev => [booking, ...prev]);



  };







  const sendMessage = async (conversationId: string, text: string) => {



    if (!currentUser) return;



    const now = new Date().toISOString();



    const newMessage: Message = {



      id: `msg-${Date.now()}`, conversationId,



      senderId: currentUser.id, senderName: currentUser.name,



      text, timestamp: now, read: false,



    };



    const { data: insertedMsg } = await supabase.from('messages').insert({



      conversation_id: conversationId,



      sender_id: currentUser.id,



      sender_name: currentUser.name,



      text,



    }).select().single();



    if (insertedMsg) newMessage.id = insertedMsg.id;



    await supabase.from('conversations').update({



      last_message: text, last_message_time: now,



    }).eq('id', conversationId);



    // Notify the other person
    const recipientId = currentUser?.role === 'guest'
      ? conv?.host_id
      : conv?.guest_id;
    if (recipientId) {
      import('../utils/notify').then((m: any) => {
        m.sendNotification({
          userId: recipientId,
          type: 'new_message',
          propertyTitle: conv?.property_title || '',
          guestName: currentUser?.role === 'guest' ? currentUser?.name : undefined,
          hostName: currentUser?.role === 'host' ? currentUser?.name : undefined,
        });
      });
    }
    setConversations(prev =>



      prev.map(c => c.id === conversationId



        ? { ...c, messages: [...c.messages, newMessage], lastMessage: text, lastMessageTime: now }



        : c



      )



    );



  };







  const sendSimulatedMessage = (conversationId: string, senderId: string, senderName: string, text: string) => {



    const newMessage: Message = {



      id: `msg-${Date.now()}`,



      conversationId,



      senderId,



      senderName,



      text,



      timestamp: new Date().toISOString(),



      read: false,



    };



    // Notify the other person
    const recipientId = currentUser?.role === 'guest'
      ? conv?.host_id
      : conv?.guest_id;
    if (recipientId) {
      import('../utils/notify').then((m: any) => {
        m.sendNotification({
          userId: recipientId,
          type: 'new_message',
          propertyTitle: conv?.property_title || '',
          guestName: currentUser?.role === 'guest' ? currentUser?.name : undefined,
          hostName: currentUser?.role === 'host' ? currentUser?.name : undefined,
        });
      });
    }
    setConversations(prev =>



      prev.map(c => c.id === conversationId



        ? { ...c, messages: [...c.messages, newMessage], lastMessage: text, lastMessageTime: new Date().toISOString() }



        : c



      )



    );



  };







  const createConversation = async (



    booking: Booking,



    participantRole: 'guest' | 'host',



    participantName: string,



    participantId: string,



    participantPhone?: string



  ): Promise<string> => {



    const conversationId = `conv-${booking.id}`;



    const existing = conversations.find(c => c.id === conversationId);



    if (existing) return conversationId;



    const property = properties.find(p => p.id === booking.propertyId);



    const now = new Date().toISOString();



    const newConversation: Conversation = {



      id: conversationId, bookingId: booking.id,



      propertyTitle: booking.propertyTitle, propertyImage: property?.image || '',



      participantId, participantName, participantPhone, participantRole,



      lastMessage: 'Start a conversation', lastMessageTime: now, unreadCount: 0, messages: [],



    };



    const isGuest = currentUser?.role === 'guest';



    await supabase.from('conversations').upsert({



      id: conversationId, booking_id: booking.id,



      property_title: booking.propertyTitle, property_image: property?.image || '',



      guest_id: isGuest ? currentUser?.id : participantId,



      host_id: isGuest ? participantId : currentUser?.id,



      participant_id: participantId, participant_name: participantName,



      participant_phone: participantPhone ?? null, participant_role: participantRole,



      last_message: 'Start a conversation', last_message_time: now,



    });



    // Notify the other person
    const recipientId = currentUser?.role === 'guest'
      ? conv?.host_id
      : conv?.guest_id;
    if (recipientId) {
      import('../utils/notify').then((m: any) => {
        m.sendNotification({
          userId: recipientId,
          type: 'new_message',
          propertyTitle: conv?.property_title || '',
          guestName: currentUser?.role === 'guest' ? currentUser?.name : undefined,
          hostName: currentUser?.role === 'host' ? currentUser?.name : undefined,
        });
      });
    }
    setConversations(prev => [newConversation, ...prev]);



    return conversationId;



  };







  const startCall = async (conversationId: string, participantName: string, participantPhone?: string, receiverId?: string, callType: string = 'audio') => {
    if (!currentUser) return;
    const { data: callRow, error: callError } = await supabase.from('calls').insert({
      conversation_id: conversationId,
      caller_id: currentUser.id,
      receiver_id: receiverId,
      call_type: callType,
      call_status: 'ringing',
      started_at: new Date().toISOString(),
    }).select().single();
    if (callError) { console.error('CALL INSERT ERROR:', JSON.stringify(callError)); } else { console.log('CALL OK:', callRow?.id); }
    setCallStatus({ active: true, conversationId, participantName, duration: 0, callId: callRow?.id, callType });
    if (callRow?.id && receiverId) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        localStreamRef.current = stream;
        const peer = createPeer();
        peerRef.current = peer;
        stream.getTracks().forEach(t => peer.addTrack(t, stream));
        peer.onicecandidate = async (e) => {
          if (e.candidate) await supabase.from('call_ice_candidates').insert({ call_id: callRow.id, user_id: currentUser.id, candidate: e.candidate.toJSON() });
        };
        peer.ontrack = (e) => { const a = document.getElementById('remote-audio') as HTMLAudioElement; if (a) { a.srcObject = e.streams[0]; a.play().catch(()=>{}); } };
        const offer = await peer.createOffer();
        await peer.setLocalDescription(offer);
        await supabase.from('calls').update({ sdp_offer: JSON.stringify(offer) }).eq('id', callRow.id);
      } catch(err) { console.error('WebRTC offer error:', err); }
    }
  };
  const acceptCall = async (call: any) => {
    setCallStatus({ active: true, conversationId: call.conversation_id, participantName: call.caller_name || 'Caller', duration: 0, callId: call.id, callType: call.call_type });
    setCallConnected(true);
    setIncomingCall(null);
    // Missed call: if caller hangs up before receiver accepts - handled in endCall
    // Missed call: if caller hangs up before receiver accepts - handled in endCall
    try {
      const { data: callData } = await supabase.from('calls').select('sdp_offer').eq('id', call.id).maybeSingle();
      if (callData?.sdp_offer) {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        localStreamRef.current = stream;
        const peer = createPeer();
        peerRef.current = peer;
        stream.getTracks().forEach(t => peer.addTrack(t, stream));
        peer.onicecandidate = async (e) => {
          if (e.candidate) await supabase.from('call_ice_candidates').insert({ call_id: call.id, user_id: currentUser?.id, candidate: e.candidate.toJSON() });
        };
        peer.ontrack = (e) => { const a = document.getElementById('remote-audio') as HTMLAudioElement; if (a) { a.srcObject = e.streams[0]; a.play().catch(()=>{}); } };
        await peer.setRemoteDescription(new RTCSessionDescription(JSON.parse(callData.sdp_offer)));
        const answer = await peer.createAnswer();
        await peer.setLocalDescription(answer);
        await supabase.from('calls').update({ sdp_answer: JSON.stringify(answer), call_status: 'accepted' }).eq('id', call.id);
        const { data: cands } = await supabase.from('call_ice_candidates').select('*').eq('call_id', call.id).neq('user_id', currentUser?.id);
        for (const cand of cands || []) { try { await peer.addIceCandidate(new RTCIceCandidate(cand.candidate)); } catch(e) {} }
      }
    } catch(err) { console.error('WebRTC answer error:', err); }
  };
  const rejectCall = async (call: any) => {
    await supabase.from('calls').update({ call_status: 'rejected', ended_at: new Date().toISOString() }).eq('id', call.id);
    setIncomingCall(null);
  };
  const endCall = async () => {
    setCallConnected(false);
    cleanupWebRTC();
    if (callStatus.callId) {
      await supabase.from('calls').update({ call_status: 'ended', ended_at: new Date().toISOString() }).eq('id', callStatus.callId);
    }
    setCallStatus({ active: false });
  };















  const markMessagesAsRead = (conversationId: string) => {



    // Notify the other person
    const recipientId = currentUser?.role === 'guest'
      ? conv?.host_id
      : conv?.guest_id;
    if (recipientId) {
      import('../utils/notify').then((m: any) => {
        m.sendNotification({
          userId: recipientId,
          type: 'new_message',
          propertyTitle: conv?.property_title || '',
          guestName: currentUser?.role === 'guest' ? currentUser?.name : undefined,
          hostName: currentUser?.role === 'host' ? currentUser?.name : undefined,
        });
      });
    }
    setConversations(prev =>



      prev.map(c => c.id === conversationId



        ? { ...c, unreadCount: 0, messages: c.messages.map(m => ({ ...m, read: true })) }



        : c



      )



    );



  };







  return (



    <AppContext.Provider value={{



      properties, currentUser, favorites, bookings, conversations,



      callStatus, callConnected, incomingCall, loading, notifications, unreadCount, markNotificationRead, markAllNotificationsRead, toggleFavorite, refreshUser, addBooking, sendMessage,



      sendSimulatedMessage, createConversation, startCall, endCall, acceptCall, rejectCall,



      markMessagesAsRead, updateUserAvatar, removeUserAvatar, logout,



    }}>



      {children}



    </AppContext.Provider>



  );



}







export function useApp() {



  const context = useContext(AppContext);



  if (!context) throw new Error('useApp must be used within an AppProvider');



  return context;



}



