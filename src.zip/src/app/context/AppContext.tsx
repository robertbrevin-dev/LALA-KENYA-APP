import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Property, User, Booking, Conversation, Message, CallStatus } from '../types';
import { supabase } from '../../lib/supabase';

interface AppContextType {
  properties: Property[];
  currentUser: User | null;
  favorites: string[];
  bookings: Booking[];
  conversations: Conversation[];
  callStatus: CallStatus;
  loading: boolean;
  toggleFavorite: (propertyId: string) => void;
  addBooking: (booking: Booking) => void;
  sendMessage: (conversationId: string, text: string) => void;
  sendSimulatedMessage: (conversationId: string, senderId: string, senderName: string, text: string) => void;
  createConversation: (
    booking: Booking,
    participantRole: 'guest' | 'host',
    participantName: string,
    participantId: string,
    participantPhone?: string
  ) => string;
  startCall: (conversationId: string, participantName: string, participantPhone?: string) => void;
  endCall: () => void;
  markMessagesAsRead: (conversationId: string) => void;
  updateUserAvatar: (url: string) => Promise<void>;
  removeUserAvatar: () => Promise<void>;
  logout: () => Promise<void>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [properties, setProperties]   = useState<Property[]>([]);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [favorites, setFavorites]     = useState<string[]>([]);
  const [bookings, setBookings]       = useState<Booking[]>([]);
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [callStatus, setCallStatus]   = useState<CallStatus>({ active: false });
  const [loading, setLoading]         = useState(true);

  const clearState = () => {
    setCurrentUser(null);
    setFavorites([]);
    setBookings([]);
    setConversations([]);
    setCallStatus({ active: false });
  };

  // ── AUTH LISTENER ──────────────────────────────────────────────
  // Supabase persists the session in localStorage automatically.
  // On app load, getSession() returns the stored session → no re-login needed.
  useEffect(() => {
    let mounted = true;

    const buildUser = async (session: any): Promise<User | null> => {
      if (!session?.user) return null;
      const u = session.user;
      // ALWAYS read role from profiles table — auth metadata is unreliable for role
      const { data: profile } = await supabase
        .from('profiles')
        .select('role, full_name, avatar_url, phone')
        .eq('id', u.id)
        .single();

      return {
        id: u.id,
        name: profile?.full_name || u.user_metadata?.full_name || u.user_metadata?.name || 'User',
        email: u.email || '',
        phone: profile?.phone || u.user_metadata?.phone || '',
        avatar: profile?.avatar_url || u.user_metadata?.avatar_url || undefined,
        role: (profile?.role as 'guest' | 'host') || 'guest',
      };
    };

    // Initial load: restore existing session
    supabase.auth.getSession().then(async ({ data: { session } }) => {
      if (!mounted) return;
      if (session) {
        const user = await buildUser(session);
        if (mounted) setCurrentUser(user);
      }
      if (mounted) setLoading(false);
    });

    // Listen for auth changes (login, logout, token refresh)
    const { data: authListener } = supabase.auth.onAuthStateChange(async (_event, session) => {
      if (!mounted) return;

      if (_event === 'SIGNED_OUT') {
        clearState();
        setLoading(false);
        window.location.href = '/';
        return;
      }

      if (_event === 'SIGNED_IN' || _event === 'TOKEN_REFRESHED' || _event === 'USER_UPDATED') {
        if (session) {
          setLoading(true);
          const user = await buildUser(session);
          if (mounted) {
            setCurrentUser(user);
            setLoading(false);
          }
        }
      }
    });

    return () => {
      mounted = false;
      authListener.subscription.unsubscribe();
    };
  }, []);

  // ── PROPERTIES ─────────────────────────────────────────────────
  useEffect(() => {
    async function fetchProperties() {
      const { data, error } = await supabase
        .from('properties')
        .select(`
          id, title, area, address, price_per_night, rating, total_reviews,
          primary_image_url, property_type, badge, bedrooms, beds, max_guests,
          description, amenities, host_id, is_featured, instant_book,
          house_rules, cancellation_policy, cleaning_fee, response_time,
          response_rate, listing_status
        `)
        .eq('listing_status', 'approved')
        .is('deleted_at', null)
        .order('created_at', { ascending: false });

      if (error) { console.error('Properties fetch error:', error.message); return; }
      if (data) {
        const mapped: Property[] = data.map((p: any) => ({
          id: p.id,
          title: p.title,
          location: p.area || p.address || 'Nairobi',
          price: p.price_per_night,
          rating: p.rating ?? 0,
          reviews: p.total_reviews ?? 0,
          image: p.primary_image_url || '🏢',
          category: p.property_type || 'Apartment',
          badge: p.badge ?? undefined,
          isFavorite: false,
          bedrooms: p.bedrooms ?? 1,
          beds: p.beds ?? 1,
          guests: p.max_guests ?? 2,
          description: p.description ?? '',
          amenities: p.amenities ?? [],
          hostId: p.host_id,
          hostName: 'Host',
          verified: p.is_featured ?? false,
          instantBook: p.instant_book ?? false,
          houseRules: p.house_rules ?? [],
          cancellationPolicy: p.cancellation_policy ?? undefined,
          cleaningFee: p.cleaning_fee ?? 0,
          responseTime: p.response_time ?? undefined,
          responseRate: p.response_rate ?? undefined,
        }));
        setProperties(mapped);
      }
    }
    fetchProperties();
  }, []);

  // ── FAVORITES ──────────────────────────────────────────────────
  useEffect(() => {
    if (!currentUser) { setFavorites([]); return; }
    supabase.from('favorites').select('property_id').eq('user_id', currentUser.id)
      .then(({ data }) => {
        if (data) {
          const ids = data.map((f: any) => f.property_id);
          setFavorites(ids);
          setProperties(prev => prev.map(p => ({ ...p, isFavorite: ids.includes(p.id) })));
        }
      });
  }, [currentUser?.id]);

  // ── CONVERSATIONS ───────────────────────────────────────────────
  useEffect(() => {
    if (!currentUser) { setConversations([]); return; }
    supabase.from('conversations')
      .select(`
        id, booking_id, property_title, property_image, 
        participant1_id, participant1_name, participant1_phone, participant1_role,
        participant2_id, participant2_name, participant2_phone, participant2_role,
        last_message, last_message_time, unread_count, updated_at
      `)
      .or(`participant1_id.eq.${currentUser.id},participant2_id.eq.${currentUser.id}`)
      .order('updated_at', { ascending: false })
      .then(({ data }) => {
        if (data) {
          const mapped: Conversation[] = data.map((c: any) => {
            const isParticipant1 = c.participant1_id === currentUser.id;
            return {
              id: c.id,
              bookingId: c.booking_id,
              propertyTitle: c.property_title,
              propertyImage: c.property_image,
              participantId: isParticipant1 ? c.participant2_id : c.participant1_id,
              participantName: isParticipant1 ? c.participant2_name : c.participant1_name,
              participantPhone: isParticipant1 ? c.participant2_phone : c.participant1_phone,
              participantRole: isParticipant1 ? c.participant2_role : c.participant1_role,
              lastMessage: c.last_message || '',
              lastMessageTime: c.last_message_time,
              unreadCount: c.unread_count || 0,
              messages: [], // Messages loaded separately when conversation opened
            };
          });
          setConversations(mapped);
        }
      });
  }, [currentUser?.id]);

  // ── BOOKINGS ───────────────────────────────────────────────────
  useEffect(() => {
    if (!currentUser) { setBookings([]); return; }
    supabase.from('bookings')
      .select('id,property_id,property_title,property_location,guest_id,guest_name,guest_phone,check_in,check_out,nights,total_amount,booking_status,created_at')
      .eq('guest_id', currentUser.id)
      .order('check_in', { ascending: false })
      .then(({ data }) => {
        if (data) {
          setBookings(data.map((b: any) => ({
            id: b.id, propertyId: b.property_id, propertyTitle: b.property_title,
            propertyLocation: b.property_location, guestId: b.guest_id, guestName: b.guest_name,
            guestPhone: b.guest_phone, checkIn: b.check_in, checkOut: b.check_out,
            nights: b.nights, totalAmount: b.total_amount, status: b.booking_status,
            createdAt: b.created_at,
          })));
        }
      });
  }, [currentUser?.id]);

  // ── FAVORITES TOGGLE ───────────────────────────────────────────
  const toggleFavorite = async (propertyId: string) => {
    if (!currentUser) return;
    const isFav = favorites.includes(propertyId);
    if (isFav) {
      setFavorites(prev => prev.filter(id => id !== propertyId));
      await supabase.from('favorites').delete().eq('property_id', propertyId).eq('user_id', currentUser.id);
    } else {
      setFavorites(prev => [...prev, propertyId]);
      await supabase.from('favorites').insert({ user_id: currentUser.id, property_id: propertyId });
    }
    setProperties(prev => prev.map(p => p.id === propertyId ? { ...p, isFavorite: !isFav } : p));
  };

  // ── ADD BOOKING ────────────────────────────────────────────────
  const addBooking = async (booking: Booking) => {
    if (!currentUser) return;
    const { error } = await supabase.from('bookings').insert({
      id: booking.id,
      property_id: booking.propertyId,
      guest_id: currentUser.id,
      host_id: properties.find(p => p.id === booking.propertyId)?.hostId,
      property_title: booking.propertyTitle,
      property_location: booking.propertyLocation,
      guest_name: booking.guestName,
      guest_phone: booking.guestPhone,
      check_in: booking.checkIn,
      check_out: booking.checkOut,
      nights: booking.nights,
      base_amount: booking.totalAmount,
      total_amount: booking.totalAmount,
      currency: 'KES',
      booking_status: booking.status,
      payment_method: (booking as any).paymentMethod,
    });
    if (!error) setBookings(prev => [booking, ...prev]);
  };

  // ── MESSAGES ───────────────────────────────────────────────────
  const sendMessage = async (conversationId: string, text: string) => {
    if (!currentUser) return;
    const newMsg: Message = {
      id: `msg-${Date.now()}`, conversationId,
      senderId: currentUser.id, senderName: currentUser.name,
      text, timestamp: new Date().toISOString(), read: false,
    };
    await supabase.from('messages').insert({ conversation_id: conversationId, sender_id: currentUser.id, sender_name: currentUser.name, text });
    setConversations(prev => prev.map(c => c.id === conversationId
      ? { ...c, messages: [...c.messages, newMsg], lastMessage: text, lastMessageTime: new Date().toISOString() }
      : c));
  };

  const sendSimulatedMessage = (conversationId: string, senderId: string, senderName: string, text: string) => {
    const newMsg: Message = {
      id: `msg-${Date.now()}`, conversationId, senderId, senderName,
      text, timestamp: new Date().toISOString(), read: false,
    };
    setConversations(prev => prev.map(c => c.id === conversationId
      ? { ...c, messages: [...c.messages, newMsg], lastMessage: text, lastMessageTime: new Date().toISOString() }
      : c));
  };

  const createConversation = (
    booking: Booking,
    participantRole: 'guest' | 'host',
    participantName: string,
    participantPhone: string
  ): string => {
    const conversationId = `conv-${Date.now()}`;
    const newConversation: Conversation = {
      id: conversationId,
      bookingId: booking.id,
      propertyTitle: booking.propertyTitle,
      propertyImage: '', // Will be populated from property data
      participantId: currentUser?.id || '',
      participantName,
      participantPhone,
      participantRole,
      lastMessage: '',
      lastMessageTime: new Date().toISOString(),
      unreadCount: 0,
      messages: [],
    };
    setConversations(prev => [...prev, newConversation]);
    return conversationId;
  };

  const startCall = (phone: string) => {
    window.location.href = `tel:${phone}`;
  };

  const endCall = () => {
    setCallStatus({ active: false });
  };

  const markMessagesAsRead = (conversationId: string) => {
    setConversations(prev => prev.map(c => 
      c.id === conversationId 
        ? { ...c, unreadCount: 0, messages: c.messages.map(m => ({ ...m, read: true })) }
        : c
    ));
  };

  const updateUserAvatar = async (file: File) => {
    if (!currentUser) return;
    
    const fileName = `avatar-${currentUser.id}-${Date.now()}`;
    const { error: uploadError } = await supabase.storage
      .from('avatars')
      .upload(fileName, file);

    if (uploadError) {
      console.error('Error uploading avatar:', uploadError);
      return;
    }

    const { data: { publicUrl } } = supabase.storage
      .from('avatars')
      .getPublicUrl(fileName);

    await supabase
      .from('profiles')
      .update({ avatar_url: publicUrl })
      .eq('id', currentUser.id);

    setCurrentUser(prev => prev ? { ...prev, avatar: publicUrl } : null);
  };

  const removeUserAvatar = async () => {
    if (!currentUser) return;

    await supabase
      .from('profiles')
      .update({ avatar_url: null })
      .eq('id', currentUser.id);

    setCurrentUser(prev => prev ? { ...prev, avatar: undefined } : null);
  };

  const logout = async () => {
    await supabase.auth.signOut();
    clearState();
  };

  return (
    <AppContext.Provider value={{
      properties, currentUser, favorites, bookings, conversations,
      callStatus, loading, toggleFavorite, addBooking, sendMessage,
      sendSimulatedMessage, createConversation, startCall, endCall,
      markMessagesAsRead, updateUserAvatar, removeUserAvatar, logout,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within an AppProvider');
  return context;
}