import { useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import BackRefreshBar from '../components/BackRefreshBar';

export default function Signup() {
  const navigate = useNavigate();

  return (
    <div className="flex items-center justify-center min-h-screen p-6">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.4 }}
        className="w-full max-w-[390px] h-[844px] rounded-[44px] overflow-hidden relative flex flex-col"
        style={{
          background: 'var(--lala-night)',
          border: '1px solid var(--lala-border)',
          boxShadow: '0 60px 120px rgba(0,0,0,0.6)',
        }}
      >
        <BackRefreshBar />
        <div className="absolute inset-0" style={{
          background: `radial-gradient(ellipse 80% 60% at 50% 20%, rgba(232,184,109,0.12) 0%, transparent 70%)`
        }} />

        <div className="relative z-10 flex flex-col flex-1 px-8 pt-20 pb-10">
          {/* Logo */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-12">
            <div className="w-[64px] h-[64px] rounded-[18px] flex items-center justify-center mx-auto mb-5"
              style={{ background: 'linear-gradient(135deg, var(--lala-gold), #C8903D)', boxShadow: '0 16px 32px rgba(232,184,109,0.3)' }}>
              <span style={{ fontFamily: 'var(--font-playfair)', fontSize: 28, fontWeight: 900, color: 'var(--lala-night)' }}>L</span>
            </div>
            <h1 style={{ fontFamily: 'var(--font-playfair)', fontSize: 32, fontWeight: 900, color: 'var(--lala-white)' }}>
              Join LALA Kenya
            </h1>
            <p className="text-[15px] mt-2" style={{ color: 'var(--lala-muted)' }}>
              How would you like to use LALA?
            </p>
          </motion.div>

          {/* Guest Card */}
          <motion.button
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.15 }}
            onClick={() => navigate('/signup/guest')}
            className="w-full rounded-[20px] p-6 mb-4 text-left cursor-pointer border-none"
            style={{
              background: 'var(--lala-card)',
              border: '1px solid var(--lala-border)',
            }}
          >
            <div className="flex items-center gap-4 mb-3">
              <div className="w-14 h-14 rounded-[16px] flex items-center justify-center text-[28px]"
                style={{ background: 'rgba(232,184,109,0.15)' }}>
                🏨
              </div>
              <div>
                <div className="text-[18px]" style={{ fontFamily: 'var(--font-playfair)', fontWeight: 800, color: 'var(--lala-white)' }}>
                  I'm a Guest
                </div>
                <div className="text-[13px]" style={{ color: 'var(--lala-muted)' }}>
                  Find and book stays
                </div>
              </div>
              <div className="ml-auto text-[20px]" style={{ color: 'var(--lala-gold)' }}>→</div>
            </div>
            <div className="flex gap-3">
              {['🔍 Browse properties', '📅 Book instantly', '💬 Message hosts'].map((item, i) => (
                <div key={i} className="text-[11px] px-2.5 py-1 rounded-[20px]"
                  style={{ background: 'rgba(232,184,109,0.1)', color: 'var(--lala-gold)', fontWeight: 500 }}>
                  {item}
                </div>
              ))}
            </div>
          </motion.button>

          {/* Host Card */}
          <motion.button
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.25 }}
            onClick={() => navigate('/signup/host')}
            className="w-full rounded-[20px] p-6 mb-8 text-left cursor-pointer border-none"
            style={{
              background: 'linear-gradient(135deg, rgba(232,184,109,0.12), rgba(62,207,178,0.06))',
              border: '1px solid rgba(232,184,109,0.25)',
            }}
          >
            <div className="flex items-center gap-4 mb-3">
              <div className="w-14 h-14 rounded-[16px] flex items-center justify-center text-[28px]"
                style={{ background: 'rgba(232,184,109,0.2)' }}>
                🏠
              </div>
              <div>
                <div className="text-[18px]" style={{ fontFamily: 'var(--font-playfair)', fontWeight: 800, color: 'var(--lala-white)' }}>
                  I'm a Host
                </div>
                <div className="text-[13px]" style={{ color: 'var(--lala-muted)' }}>
                  List your space & earn
                </div>
              </div>
              <div className="ml-auto text-[20px]" style={{ color: 'var(--lala-gold)' }}>→</div>
            </div>
            <div className="flex gap-3 flex-wrap">
              {['💰 Earn money', '📊 Track bookings', '⭐ Build reviews'].map((item, i) => (
                <div key={i} className="text-[11px] px-2.5 py-1 rounded-[20px]"
                  style={{ background: 'rgba(232,184,109,0.15)', color: 'var(--lala-gold)', fontWeight: 500 }}>
                  {item}
                </div>
              ))}
            </div>
          </motion.button>

          {/* Login link */}
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4 }}
            className="text-center mt-auto">
            <span className="text-[14px]" style={{ color: 'var(--lala-muted)' }}>Already have an account? </span>
            <button onClick={() => navigate('/login')}
              style={{ color: 'var(--lala-gold)', fontWeight: 600, background: 'none', border: 'none', cursor: 'pointer', fontSize: 14 }}>
              Sign in
            </button>
          </motion.div>
        </div>
      </motion.div>
    </div>
  );
}
