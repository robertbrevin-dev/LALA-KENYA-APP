export default function StatusBar() {
  return (
    <div 
      className="flex justify-between items-center px-6 pt-3 pb-2 text-xs"
      style={{ 
        color: 'var(--lala-text)',
        fontWeight: 600
      }}
    >
      <span>9:41</span>
      <span>●●● ◼◼</span>
    </div>
  );
}
