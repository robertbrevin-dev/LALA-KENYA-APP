import { useNavigate, useLocation } from 'react-router-dom';

interface NavItem {
  icon: string;
  label: string;
  path: string;
}

const guestNavItems: NavItem[] = [
  { icon: '🏠', label: 'Explore', path: '/home' },
  { icon: '🗺️', label: 'Map', path: '/map' },
  { icon: '📋', label: 'Trips', path: '/trips' },
  { icon: '💬', label: 'Messages', path: '/messages' },
  { icon: '👤', label: 'Profile', path: '/profile' },
];

const hostNavItems: NavItem[] = [
  { icon: '📊', label: 'Dashboard', path: '/host' },
  { icon: '🏠', label: 'Listings', path: '/host/listings' },
  { icon: '📋', label: 'Bookings', path: '/host/bookings' },
  { icon: '💰', label: 'Earnings', path: '/host/earnings' },
  { icon: '👤', label: 'Profile', path: '/host/profile' },
];

interface BottomNavProps {
  type?: 'guest' | 'host';
}

export default function BottomNav({ type = 'guest' }: BottomNavProps) {
  const navigate = useNavigate();
  const location = useLocation();
  const items = type === 'host' ? hostNavItems : guestNavItems;

  return (
    <div
      className="mt-auto py-2 pb-6 px-2 flex justify-around items-center"
      style={{
        background: 'var(--lala-deep)',
        borderTop: '1px solid var(--lala-border)',
      }}
    >
      {items.map((item) => {
        const isActive = location.pathname === item.path;
        return (
          <button
            key={item.path}
            onClick={() => navigate(item.path)}
            className="flex flex-col items-center gap-1 border-none bg-transparent cursor-pointer transition-all px-3 py-1 rounded-[12px]"
            style={{
              color: isActive ? 'var(--lala-gold)' : 'var(--lala-muted)',
              fontWeight: isActive ? 700 : 500,
              background: isActive ? 'rgba(232,184,109,0.08)' : 'transparent',
              minWidth: 52,
            }}
          >
            <span
              className="text-[22px]"
              style={{
                filter: isActive ? 'drop-shadow(0 0 6px rgba(232,184,109,0.5))' : 'none',
                transform: isActive ? 'scale(1.15)' : 'scale(1)',
                transition: 'all 0.2s ease',
                display: 'block',
              }}
            >
              {item.icon}
            </span>
            <span className="text-[10px]">{item.label}</span>
          </button>
        );
      })}
    </div>
  );
}